# Kontrol Lampu - Android Home Screen Widget

Project Android Studio untuk widget ON/OFF ESP32 melalui MQTT.

## Konfigurasi bawaan
- Broker TLS: `ssl://broker.hivemq.com:8883`
- Topic: `kontrol_lampu_esp32_ku/sakelar`
- Payload: `ON` / `OFF`
- Retained message: `true`

Konfigurasi ini mengikuti file HTML yang diberikan. HTML memakai HiveMQ WebSocket pada port 8884; aplikasi Android ini memakai MQTT TLS TCP pada port 8883.

## Membuat APK
1. Buka Android Studio.
2. Pilih **Open** lalu pilih folder `LampuWidget`.
3. Tunggu Gradle Sync dan unduh dependency jika diminta.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Instal APK pada Android.
6. Tekan lama area kosong home screen > **Widget** > **Kontrol Lampu** > tambahkan widget.

## Catatan penting
- Pastikan firmware ESP32 subscribe ke topic `kontrol_lampu_esp32_ku/sakelar` dan menerima payload `ON` / `OFF`.
- Widget menampilkan status pengiriman perintah, bukan konfirmasi kondisi fisik lampu. File HTML asal juga hanya mengubah indikator secara lokal setelah publish. Untuk status lampu yang benar-benar terverifikasi, firmware ESP32 perlu menerbitkan status balik pada topic terpisah dan widget perlu ditambah mekanisme subscribe/pembaruan status.
- Topic pada broker publik dapat diakses pihak lain yang mengetahui nama topic. Ganti dengan topic acak yang unik atau broker privat sebelum digunakan untuk instalasi nyata.
