package com.arul.lampuwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.eclipse.paho.client.mqttv3.MqttClient
import org.eclipse.paho.client.mqttv3.MqttConnectOptions
import org.eclipse.paho.client.mqttv3.MqttMessage
import java.util.UUID
import java.util.concurrent.Executors

class LampWidgetProvider : AppWidgetProvider() {
    companion object {
        private const val ACTION_ON = "com.arul.lampuwidget.ACTION_ON"
        private const val ACTION_OFF = "com.arul.lampuwidget.ACTION_OFF"
        private const val BROKER = "ssl://broker.hivemq.com:8883"
        private const val TOPIC = "kontrol_lampu_esp32_ku/sakelar"
        private val executor = Executors.newSingleThreadExecutor()

        private fun updateWidget(context: Context, manager: AppWidgetManager, id: Int, status: String, connection: String) {
            val views = RemoteViews(context.packageName, R.layout.widget_lamp)
            views.setTextViewText(R.id.lampStatus, status)
            views.setTextViewText(R.id.connectionStatus, connection)
            views.setOnClickPendingIntent(R.id.buttonOn, actionIntent(context, ACTION_ON, id * 10 + 1))
            views.setOnClickPendingIntent(R.id.buttonOff, actionIntent(context, ACTION_OFF, id * 10 + 2))
            manager.updateAppWidget(id, views)
        }

        private fun actionIntent(context: Context, action: String, requestCode: Int): PendingIntent {
            val intent = Intent(context, LampWidgetProvider::class.java).setAction(action)
            return PendingIntent.getBroadcast(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, manager, it, "●  Status: belum diketahui", "MQTT") }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val command = when (intent.action) {
            ACTION_ON -> "ON"
            ACTION_OFF -> "OFF"
            else -> return
        }
        val manager = AppWidgetManager.getInstance(context)
        val component = ComponentName(context, LampWidgetProvider::class.java)
        val ids = manager.getAppWidgetIds(component)
        ids.forEach { updateWidget(context, manager, it, "◌  Mengirim $command...", "MENGIRIM") }

        val pending = goAsync()
        executor.execute {
            var client: MqttClient? = null
            try {
                val clientId = "LampWidget-" + UUID.randomUUID().toString().replace("-", "").take(12)
                client = MqttClient(BROKER, clientId, null)
                val options = MqttConnectOptions().apply {
                    isCleanSession = true
                    connectionTimeout = 10
                    keepAliveInterval = 20
                    isAutomaticReconnect = false
                }
                client.connect(options)
                val message = MqttMessage(command.toByteArray(Charsets.UTF_8)).apply {
                    qos = 0
                    isRetained = true
                }
                client.publish(TOPIC, message)
                ids.forEach { updateWidget(context, manager, it, "●  Perintah terkirim: $command", "TERKIRIM") }
            } catch (e: Exception) {
                ids.forEach { updateWidget(context, manager, it, "!  Gagal mengirim. Cek internet", "ERROR") }
            } finally {
                try { if (client?.isConnected == true) client.disconnect() } catch (_: Exception) {}
                try { client?.close() } catch (_: Exception) {}
                pending.finish()
            }
        }
    }
}
